//oggetti
let player;
let labirinto = [];

//immagini
let player_image;
let pagina_iniziale;
let pagina_selezione;
let impostazioni;
let casa;
let pezzo_puzzle;
let sfondo_labirinto;
let sfondo_galleria;
let img_bianca;
let icona_galleria;

let quadro1 = false;
let quadro2 = false;
let quadro3 = true;

let gioconda;
let gioconda_alto_destra;
let gioconda_alto_sinistra;
let gioconda_basso_destra;
let gioconda_basso_sinistra;

let vaso;
let vaso_alto_destra;
let vaso_alto_sinistra;
let vaso_basso_destra;
let vaso_basso_sinistra;

let onde;
let onde_alto_destra;
let onde_alto_sinistra;
let onde_basso_destra;
let onde_basso_sinistra;

let righe;
let colonne;
let obj_premuto = false;
let image1_premuta = false;
let image2_premuta = false;
let image3_premuta = false;
let image4_premuta = false;
let DIM;
let offX, offY, targetX, targetY;
let img1X, img1Y, img2X, img2Y, img3X, img3Y, img4X, img4Y;
let r, c;

let musica = true;
let song_titolo;
let song_livello_1;
let song_livello_2;
let song_livello_3;

let pezzo1 = false;
let pezzo2 = false;
let pezzo3 = false;
let pezzo4 = false;

let pezzi;
let tocchi = 0;

//numero della scena
let scena = 0;

//////////////////////////////////////////////////////////////////////////////////////////////////// PRELOAD ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function preload() {
  //loadImage serve per caricare un immagine
  player_image = loadImage('gif_player.png');
  pagina_iniziale = loadImage('pagina_iniziale.png');
  pagina_selezione = loadImage('pagina_selezione.png');
  impostazioni = loadImage('rotella_impostazioni.png');
  casa = loadImage('casa.png');
  pezzo_puzzle = loadImage('pezzo_puzzle.png');
  sfondo_labirinto = loadImage('sfondo_labirinti.png');
  img_bianca = loadImage('img_bianca.png');
  sfondo_galleria = loadImage('sfondo_galleria.png');
  icona_galleria = loadImage('icona_galleria.png');

  gioconda = loadImage('gioconda.png');
  gioconda_alto_destra = loadImage('gioconda_alto_destra.png');
  gioconda_alto_sinistra = loadImage('gioconda_alto_sinistra.png');
  gioconda_basso_destra = loadImage('gioconda_basso_destra.png');
  gioconda_basso_sinistra =loadImage('gioconda_basso_sinistra.png');

  vaso = loadImage('vaso.png');
  vaso_alto_destra = loadImage('vaso_alto_destra.png');
  vaso_alto_sinistra = loadImage('vaso_alto_sinistra.png');
  vaso_basso_destra = loadImage('vaso_basso_destra.png');
  vaso_basso_sinistra =loadImage('vaso_basso_sinistra.png');

  onde = loadImage('onde.png');
  onde_alto_destra = loadImage('onde_alto_destra.png');
  onde_alto_sinistra = loadImage('onde_alto_sinistra.png');
  onde_basso_destra = loadImage('onde_basso_destra.png');
  onde_basso_sinistra =loadImage('onde_basso_sinistra.png');

  //song_titolo = loadSound('titolo.mp3');
  //song_livello_1 = loadSound();
  //song_livello_2 = loadSound();
  //song_livello_3 = loadSound('3L.mp3');
}

//////////////////////////////////////////////////////////////////////////////////////////////////// SETUP ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function setup() {
  createCanvas(windowWidth, windowHeight);

  //elimina i bordi
  noStroke(); 

  //dichiarazione righe e colonne
  righe = 25;
  colonne = 29;
  pezzi = 0;
  DIM = min(floor(windowWidth / colonne), floor(windowHeight / righe));

  img1X = windowWidth - (windowWidth - DIM * 45);
  img1Y = windowHeight - (windowHeight - 20);

  img2X = windowWidth - (windowWidth - DIM * 45);
  img2Y = windowHeight - (windowHeight - DIM * 6);

  img3X = windowWidth - (windowWidth - DIM * 45);
  img3Y = windowHeight - (windowHeight - DIM * 12);

  img4X = windowWidth - (windowWidth - DIM * 45);
  img4Y = windowHeight - (windowHeight - DIM * 18);

  //creazione degli oggetti

  for(let i = 0; i < righe; i++){
    labirinto[i] = [];  //matrice (come costruzione arrayMulti di java)
    for(let j = 0; j < colonne; j++) {
      labirinto[i][j] = new Muro(DIM*j, DIM*i);
    }
  }

  player = new Player();

  //song_titolo.play();
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  DIM = min(floor(windowWidth / colonne), floor(windowHeight / righe));
}

//////////////////////////////////////////////////////////////////////////////////////////////////// DRAW ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function draw() {
  //per settare lo sfondo
  background(220);

  for(let i = 0; i < righe; i++) {
    for(let j = 0; j < colonne; j++) {
      //funzioni del labirinto
      labirinto[i][j].show();
    }
  }

  if (collisione_muro()) {

    let r = floor((player.y + player.dim/2) / DIM); 
    let c = floor((player.x + player.dim/2) / DIM);

    if (labirinto[r][c].muro) {

      let d = dist(player.x + (DIM * 1.5)/2, player.y + DIM/2, labirinto[r][c].x + (DIM * 1.5)/2, labirinto[r][c].y + DIM/2);
      if(d < (DIM * 4)){
        if (player.x < c * DIM) {
          player.x = (c - 1) * DIM - (DIM * 1.5)/2;
          console.log("destra");  //CHECK
          this.obj_premuto = false;
          tocchi += 1;
        } else{
          player.x = (c + 1) * DIM + (DIM * 1.5)/2;
          console.log("sinistra");  //CHECK
          this.obj_premuto = false;
          tocchi += 1;
        }
  
        if (player.y < r * DIM) {
          player.y = (r - 1) * DIM - (DIM * 1.5)/2 - 1;
          console.log("sopra");  //CHECK
          this.obj_premuto = false;
          tocchi += 1;
        } else {
          player.y = (r + 1) * DIM + (DIM * 1.5)/2;
          console.log("sotto");  //CHECK
          this.obj_premuto = false;
          tocchi += 1;
        }
      }
    }
  }

  //funzione per cambiare le schermate
  funzione = "screen" + (scena + 1);
  window[funzione]();

}

//////////////////////////////////////////////////////////////////////////////////////////////////// MOVIMENTO ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function mousePressed(){

  //PER HITBOX
  if(mouseX > player.x && mouseX < player.x + DIM * 1.5 && mouseY > player.y && mouseY < player.y + DIM * 1.5){         
    offX = mouseX - player.x;
    offY = mouseY - player.y;
    this.obj_premuto = true;
  }

  //ROTELLA IMPOSTAZIONI
  if(mouseIsPressed && mouseX > windowWidth - (windowWidth - 10) && mouseX < windowWidth - (windowWidth - DIM * 5) && 
    mouseY > windowHeight - (windowHeight - 10) && mouseY < windowHeight - (windowHeight - DIM * 5)){
    if(scena == 0){
      //SCHERMATA IMPOSTAZIONI
      scena = 1;
    }
    if(scena == 1){
      //SCHERMATA IMPOSTAZIONI
      scena = 1;
    }
    if(scena == 2){
      //SCHERMATA IMPOSTAZIONI
      scena = 1;
    }
    if(scena == 6){
      //SCHERMATA IMPOSTAZIONI
      scena = 1;
    }
    if(scena == 7){
      //SCHERMATA IMPOSTAZIONI
      scena = 1;
    }
    if(scena == 8){
      //SCHERMATA IMPOSTAZIONI
      scena = 1;
    }
    if(scena == 9){
      //SCHERMATA IMPOSTAZIONI
      scena = 1;
    }
  }
  
  if(mouseIsPressed && mouseX > windowWidth - (windowWidth - 10) && mouseX < windowWidth - (windowWidth - DIM * 5) && 
  mouseY > windowHeight - (windowHeight - DIM * 5) && mouseY < windowHeight - (windowHeight - DIM * 10)){
    if(scena == 1){
      //SCHERMATA INIZIALE
      window.location.reload()
    }
    if(scena == 2){
      //SCHERMATA INIZIALE
      window.location.reload()
    }
    if(scena == 6){
      //SCHERMATA INIZIALE
      window.location.reload()
    }
    if(scena == 7){
      //SCHERMATA INIZIALE
      window.location.reload()
    }
    if(scena == 8){
      //SCHERMATA INIZIALE
      window.location.reload()
    }
    if(scena == 9){
      //SCHERMATA INIZIALE
      window.location.reload()
    }
  }

  //ICONA GALLERIA HOME
  if(mouseIsPressed && mouseX > windowWidth - (windowWidth - (DIM * 6)) && mouseX < windowWidth - (windowWidth - (DIM * 11)) && 
  mouseY > windowHeight - (windowHeight - 10) && mouseY < windowHeight - (windowHeight - (DIM * 6))){
    if(scena == 0){
      //SCHERMATA GALLERIA
      scena = 9;
    }
  }
  
  //ICONA GALLERIA
  if(mouseIsPressed && mouseX > windowWidth - (windowWidth - 10) && mouseX < windowWidth - (windowWidth - DIM * 5) && 
  mouseY > windowHeight - (windowHeight - DIM * 11) && mouseY < windowHeight - (windowHeight - DIM * 16)){
    if(scena == 6){
      //SCHERMATA GALLERIA
      scena = 9;
    }
    if(scena == 7){
      //SCHERMATA GALLERIA
      scena = 9;
    }
    if(scena == 8){
      //SCHERMATA GALLERIA
      scena = 9;
    }
  }

  if (mouseIsPressed && mouseX > 0 && mouseY > 0) {
    if(scena == 0){
      //SCHERMATA SCELTA LIVELLO
      scena = 2;
    }
  }
    
  //LABIRINTO 1
  if(mouseIsPressed && mouseY <= ((windowHeight / 2) - DIM * 4) && mouseY > ((windowHeight / 2) - DIM * 5) - DIM * 2){
    if(scena == 2){
      //SCHERMATA LIVELLO 1
      player.x = player.x_inizio;
      player.y = player.y_inizio;
      scena = 3;
    }
  }
  //LABIRINTO 2
  if(mouseIsPressed && mouseY <= (windowHeight / 2) && mouseY > ((windowHeight / 2) - DIM * 3.5)){
    if(scena == 2){
      //SCHERMATA LIVELLO 2
      player.x = player.x_inizio;
      player.y = player.y_inizio;
      scena = 4;
    }
  }
  //LABIRINTO 3
  if(mouseIsPressed && mouseY <= (windowHeight / 2) + DIM * 4 && mouseY > ((windowHeight / 2) + DIM)){
    if(scena == 2){
      //SCHERMATA LIVELLO 3
      player.x = player.x_inizio;
      player.y = player.y_inizio;
      scena = 5;
    }
  }

  //IMPOSTAZIONI NEI LABIRINTI
  if(mouseIsPressed && mouseX > (windowWidth - (DIM * 6)) && mouseX < windowWidth && 
    mouseY > windowHeight - (windowHeight - 10) && mouseY < windowHeight - (windowHeight - DIM * 5)){
    if(scena == 3){
      //SCHERMATA IMPOSTAZIONI
      scena = 1;
    }
    if(scena == 4){
      //SCHERMATA IMPOSTAZIONI
      scena = 1;
    }
    if(scena == 5){
      //SCHERMATA IMPOSTAZIONI
      scena = 1;
    }
  }

  //CASA NEI LABIRINTI
  if(mouseIsPressed && mouseX > (windowWidth - (DIM * 6)) && mouseX < windowWidth && 
    mouseY > windowHeight - (windowHeight - DIM * 5) && mouseY < windowHeight - (windowHeight - DIM * 10)){
    if(scena == 3){
      //SCHERMATA INIZIALE
      window.location.reload()
    }
    if(scena == 4){
      //SCHERMATA INIZIALE
      window.location.reload()
    }
    if(scena == 5){
      //SCHERMATA INIZIALE
      window.location.reload()
    }
  }

  if(mouseIsPressed && mouseX > img1X && mouseX < img1X + (DIM * 5) && mouseY > img1Y && mouseY < img1Y + (DIM * 5)){
    targetX = mouseX - img1X;
    targetY = mouseY - img1Y;
    this.image1_premuta = true;
  }
  if(mouseIsPressed && mouseX > img2X && mouseX < img2X + (DIM * 5) && mouseY > img2Y && mouseY < img2Y + (DIM * 5)){
    targetX = mouseX - img2X;
    targetY = mouseY - img2Y;
    this.image2_premuta = true;
  }
  if(mouseIsPressed && mouseX > img3X && mouseX < img3X + (DIM * 5) && mouseY > img3Y && mouseY < img3Y + (DIM * 5)){
    targetX = mouseX - img3X;
    targetY = mouseY - img3Y;
    this.image3_premuta = true;
  }
  if(mouseIsPressed && mouseX > img4X && mouseX < img4X + (DIM * 5) && mouseY > img4Y && mouseY < img4Y + (DIM * 5)){
    targetX = mouseX - img4X;
    targetY = mouseY - img4Y;
    this.image4_premuta = true;
  }
}

function mouseDragged() {
  if (this.obj_premuto) {
    player.x = mouseX - offX;
    player.y = mouseY - offY;
  }
  if(this.image1_premuta){
    img1X = mouseX - targetX;
    img1Y = mouseY - targetY;
  }
  if(this.image2_premuta){
    img2X = mouseX - targetX;
    img2Y = mouseY - targetY;
  }
  if(this.image3_premuta){
    img3X = mouseX - targetX;
    img3Y = mouseY - targetY;
  }
  if(this.image4_premuta){
    img4X = mouseX - targetX;
    img4Y = mouseY - targetY;
  }
}

function mouseReleased() {
  this.obj_premuto = false;

  this.image1_premuta = false;
  this.image2_premuta = false;
  this.image3_premuta = false;
  this.image4_premuta = false;
}

function collisione_muro(){
  let r = floor((player.y + player.dim/2) / DIM); 
  let c = floor((player.x + player.dim/2) / DIM);
  return labirinto[r][c].muro === true;
}

//////////////////////////////////////////////////////////////////////////////////////////////////// SCREEN ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//SCHERMATA INIZIALE
function screen1(){
  background(pagina_iniziale);
  image(impostazioni, windowWidth - (windowWidth - 10), windowHeight - (windowHeight - 10), DIM * 5, DIM * 5);
  image(icona_galleria, windowWidth - (windowWidth - (DIM * 6)), windowHeight - (windowHeight - 10), DIM * 5, DIM * 5);
}

//SCHERMATA IMPOSTAZIONI
function screen2(){
  background(220);
  image(casa, windowWidth - (windowWidth - 10), windowHeight - (windowHeight - DIM * 5), DIM * 5, DIM * 5);
  image(impostazioni, windowWidth - (windowWidth - 10), windowHeight - (windowHeight - 10), DIM * 5, DIM * 5);

  fill(0, 0, 0);
  textSize(DIM * 2);
  text("COMANDI: ", windowWidth - (windowWidth - DIM * 8), windowHeight - (windowHeight - DIM * 5));
  textSize(DIM);
  text("1. trascina con il dito il personaggio in giro per il labirinto,raccogli tutti i pezzi e trova l'uscita\n2. ricostruisci la figura trascinando i pezzi nella posizione corretta\n3. guarda le opere completate nella galleria", windowWidth - (windowWidth - DIM * 8), windowHeight - (windowHeight - DIM * 7));
}

//SCHERMATA SCELTA LIVELLO
function screen3(){
  background(pagina_selezione);
  image(impostazioni, windowWidth - (windowWidth - 10), windowHeight - (windowHeight - 10), DIM * 5, DIM * 5);
  image(casa, windowWidth - (windowWidth - 10), windowHeight - (windowHeight - DIM * 5), DIM * 5, DIM * 5);
}

//////////////////////////////////////////////////////////////////////////////////////////////////// LABIRINTO 1 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function screen4(){                          
  background(sfondo_labirinto);
  textSize(DIM * 1.75);
  textStyle(ITALIC);
  text("tempo: " + player.tempo, windowWidth - (DIM * 14), windowHeight - (windowHeight - (DIM * 5)));
  text("tocchi: " + tocchi/2, windowWidth - (DIM * 14), windowHeight - (windowHeight - (DIM * 13)));
  text("pezzi raccolti: " + pezzi, windowWidth - (DIM * 14), windowHeight - (windowHeight - (DIM * 21)));
  image(impostazioni, windowWidth - (DIM * 6), windowHeight - (windowHeight - 10), DIM * 5, DIM * 5);
  image(casa, windowWidth - (DIM * 6), windowHeight - (windowHeight - DIM * 5), DIM * 5, DIM * 5);
  player.show();
  player.move();

  //crea tutta la griglia sotto (mette i muri)

  let r = 23;
  let c = 25;
  
  for(let i = 0; i < c; i++) {  //mette i muri a tutta la prima riga e l'ultima
    if(i >= 4){
      labirinto[0][i].muro = true;
    }
    labirinto[r-1][i].muro = true;
    labirinto[0][i].show();
    labirinto[r-1][i].show();
  }
  for(let i = 0; i < r; i++) {   //mette i muri a tutta la prima colonna e l'ultima
    labirinto[i][0].muro = true;
    if(i <= (r - 7) || i >= (r - 3)){
      labirinto[i][c-1].muro = true;
    }
    labirinto[i][0].show();
    labirinto[i][c-1].show();
  }

  let dist1 = dist(player.x, player.y, labirinto[12][6].x, labirinto[12][6].y);
  let dist2 = dist(player.x, player.y, labirinto[2][10].x, labirinto[2][10].y);
  let dist3 = dist(player.x, player.y, labirinto[6][22].x, labirinto[6][22].y);
  let dist4 = dist(player.x, player.y, labirinto[14][17].x, labirinto[14][17].y);
  
  if(pezzo1 === true){
    image(img_bianca, labirinto[12][6].x, labirinto[12][6].y, DIM, DIM);
  }else{
    image(pezzo_puzzle, labirinto[12][6].x, labirinto[12][6].y, DIM, DIM);
  }

  if(pezzo2 === true){
    image(img_bianca, labirinto[2][10].x, labirinto[2][10].y, DIM, DIM);
  }else{
    image(pezzo_puzzle, labirinto[2][10].x, labirinto[2][10].y, DIM, DIM);
  }

  if(pezzo3 === true){
    image(img_bianca, labirinto[6][22].x, labirinto[6][22].y, DIM, DIM);
  }else{
    image(pezzo_puzzle, labirinto[6][22].x, labirinto[6][22].y, DIM, DIM);
  }

  if(pezzo4 === true){
    image(img_bianca, labirinto[14][17].x, labirinto[14][17].y, DIM, DIM);
  }else{
    image(pezzo_puzzle, labirinto[14][17].x, labirinto[14][17].y, DIM, DIM);
  }

  if(dist1 < DIM && pezzo1 === false){
    text("BRAVO HAI PRESO UN PEZZO", windowWidth - (DIM * 15), windowHeight - (windowHeight - (DIM * 7)));
    pezzo1 = true;
    pezzi += 1;
    
  }
  if(dist2 < DIM && pezzo2 === false){
    text("BRAVO HAI PRESO UN PEZZO", windowWidth - (DIM * 15), windowHeight - (windowHeight - (DIM * 7)));
    pezzo2 = true;
    pezzi += 1;
  }
  if(dist3 < DIM && pezzo3 === false){
    text("BRAVO HAI PRESO UN PEZZO", windowWidth - (DIM * 15), windowHeight - (windowHeight - (DIM * 7)));
    pezzo3 = true;
    pezzi += 1;
  }
  if(dist4 < DIM && pezzo4 === false){
    text("BRAVO HAI PRESO UN PEZZO", windowWidth - (DIM * 15), windowHeight - (windowHeight - (DIM * 7)));
    pezzo4 = true;
    pezzi += 1;
  }

  //uscita
  if(player.x > ((c * DIM))){
    scena = 6
    record1 = (player.tempo / 1000);
  }
  
  //creazione labirinto
  
  //RIGA 1
  labirinto[1][4].muro = true;
  labirinto[1][4].show();
  
  //RIGA 2
  labirinto[2][4].muro = true;    
  labirinto[2][4].show(); 

  //RIGA 3
  labirinto[3][4].muro = true;    
  labirinto[3][4].show(); 

  //RIGA 4
  labirinto[4][4].muro = true;    
  labirinto[4][4].show(); 
  labirinto[4][8].muro = true;    
  labirinto[4][8].show();
  labirinto[4][9].muro = true;    
  labirinto[4][9].show();
  labirinto[4][10].muro = true;   
  labirinto[4][10].show();
  labirinto[4][11].muro = true;   
  labirinto[4][11].show();
  labirinto[4][12].muro = true;   
  labirinto[4][12].show();
  labirinto[4][13].muro = true;   
  labirinto[4][13].show();
  labirinto[4][14].muro = true;   
  labirinto[4][14].show();
  labirinto[4][15].muro = true;   
  labirinto[4][15].show();
  labirinto[4][16].muro = true;   
  labirinto[4][16].show();
  labirinto[4][20].muro = true;   
  labirinto[4][20].show();

  //RIGA 5
  labirinto[5][4].muro = true;    
  labirinto[5][4].show(); 
  labirinto[5][12].muro = true;   
  labirinto[5][12].show();
  labirinto[5][20].muro = true;   
  labirinto[5][20].show();
 
  //RIGA 6
  labirinto[6][4].muro = true;    
  labirinto[6][4].show(); 
  labirinto[6][12].muro = true;   
  labirinto[6][12].show(); 
  labirinto[6][20].muro = true;   
  labirinto[6][20].show(); 

  //RIGA 7
  labirinto[7][4].muro = true;    
  labirinto[7][4].show();
  labirinto[7][12].muro = true;   
  labirinto[7][12].show(); 
  labirinto[7][20].muro = true;   
  labirinto[7][20].show();

  //RIGA 8
  labirinto[8][4].muro = true;    
  labirinto[8][4].show();
  labirinto[8][5].muro = true;    
  labirinto[8][5].show();
  labirinto[8][6].muro = true;    
  labirinto[8][6].show();
  labirinto[8][7].muro = true;    
  labirinto[8][7].show();
  labirinto[8][8].muro = true;    
  labirinto[8][8].show();
  labirinto[8][12].muro = true;   
  labirinto[8][12].show();
  labirinto[8][16].muro = true;   
  labirinto[8][16].show();
  labirinto[8][17].muro = true;   
  labirinto[8][17].show();
  labirinto[8][18].muro = true;   
  labirinto[8][18].show();
  labirinto[8][19].muro = true;   
  labirinto[8][19].show();
  labirinto[8][20].muro = true;   
  labirinto[8][20].show();
  labirinto[8][21].muro = true;   
  labirinto[8][21].show();
  labirinto[8][22].muro = true;   
  labirinto[8][22].show();
  labirinto[8][23].muro = true;   
  labirinto[8][23].show();

  //RIGA 9
  labirinto[9][4].muro = true;    
  labirinto[9][4].show();
  labirinto[9][12].muro = true;   
  labirinto[9][12].show();

  //RIGA 10
  labirinto[10][4].muro = true;   
  labirinto[10][4].show(); 
  labirinto[10][12].muro = true;  
  labirinto[10][12].show();  
  
  //RIGA 11
  labirinto[11][4].muro = true;   
  labirinto[11][4].show();
  labirinto[11][12].muro = true;  
  labirinto[11][12].show();

  //RIGA 12
  labirinto[12][4].muro = true;   
  labirinto[12][4].show();
  labirinto[12][8].muro = true;   
  labirinto[12][8].show();
  labirinto[12][9].muro = true;   
  labirinto[12][9].show();
  labirinto[12][10].muro = true;  
  labirinto[12][10].show();
  labirinto[12][11].muro = true;  
  labirinto[12][11].show();
  labirinto[12][12].muro = true;  
  labirinto[12][12].show();
  labirinto[12][13].muro = true;  
  labirinto[12][13].show();
  labirinto[12][14].muro = true;  
  labirinto[12][14].show();
  labirinto[12][15].muro = true;  
  labirinto[12][15].show();
  labirinto[12][16].muro = true;  
  labirinto[12][16].show();
  labirinto[12][17].muro = true;  
  labirinto[12][17].show();
  labirinto[12][18].muro = true;  
  labirinto[12][18].show();
  labirinto[12][19].muro = true;  
  labirinto[12][19].show();
  labirinto[12][20].muro = true;  
  labirinto[12][20].show();

  //RIGA 13
  labirinto[13][4].muro = true;   
  labirinto[13][4].show();
  labirinto[13][8].muro = true;   
  labirinto[13][8].show();

  //RIGA 14
  labirinto[14][4].muro = true;   
  labirinto[14][4].show();
  labirinto[14][8].muro = true;   
  labirinto[14][8].show();

  //RIGA 15
  labirinto[15][4].muro = true;   
  labirinto[15][4].show();
  labirinto[15][8].muro = true;   
  labirinto[15][8].show();

  //RIGA 16
  labirinto[16][4].muro = true;   
  labirinto[16][4].show();
  labirinto[16][8].muro = true;   
  labirinto[16][8].show();
  labirinto[16][12].muro = true;  
  labirinto[16][12].show();
  labirinto[16][13].muro = true;  
  labirinto[16][13].show();
  labirinto[16][14].muro = true;  
  labirinto[16][14].show();
  labirinto[16][15].muro = true;  
  labirinto[16][15].show();
  labirinto[16][16].muro = true;  
  labirinto[16][16].show();
  labirinto[16][17].muro = true;  
  labirinto[16][17].show();
  labirinto[16][18].muro = true;  
  labirinto[16][18].show();
  labirinto[16][19].muro = true;  
  labirinto[16][19].show();
  labirinto[16][20].muro = true;  
  labirinto[16][20].show();
  labirinto[16][21].muro = true;  
  labirinto[16][21].show();
  labirinto[16][22].muro = true;  
  labirinto[16][22].show();
  labirinto[16][23].muro = true;  
  labirinto[16][23].show();

  //RIGA 17
  labirinto[17][8].muro = true;   
  labirinto[17][8].show();
  labirinto[17][4].muro = true;   
  labirinto[17][4].show();
  labirinto[17][12].muro = true;  
  labirinto[17][12].show();
  labirinto[17][20].muro = true;  
  labirinto[17][20].show();
  
  //RIGA 18
  labirinto[18][8].muro = true;   
  labirinto[18][8].show();
  labirinto[18][4].muro = true;   
  labirinto[18][4].show();
  labirinto[18][12].muro = true;  
  labirinto[18][12].show();
  labirinto[18][20].muro = true;  
  labirinto[18][20].show();

  //RIGA 19
  labirinto[19][8].muro = true;   
  labirinto[19][8].show();

  //RIGA 20
  labirinto[20][8].muro = true;   
  labirinto[20][8].show();
  labirinto[20][16].muro = true;  
  labirinto[20][16].show();

  //RIGA 21
  labirinto[21][8].muro = true;   
  labirinto[21][8].show();
  labirinto[21][16].muro = true;  
  labirinto[21][16].show();

}

//////////////////////////////////////////////////////////////////////////////////////////////////// LABIRINTO 2 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function screen5(){                          
  background(sfondo_labirinto);
  textSize(DIM * 1.75);
  textStyle(ITALIC);
  text("tempo: " + player.tempo, windowWidth - (DIM * 14), windowHeight - (windowHeight - (DIM * 5)));
  text("tocchi: " + tocchi/2, windowWidth - (DIM * 14), windowHeight - (windowHeight - (DIM * 13)));
  text("pezzi raccolti: " + pezzi, windowWidth - (DIM * 14), windowHeight - (windowHeight - (DIM * 21)));
  image(impostazioni, windowWidth - (DIM * 6), windowHeight - (windowHeight - 10), DIM * 5, DIM * 5);
  image(casa, windowWidth - (DIM * 6), windowHeight - (windowHeight - DIM * 5), DIM * 5, DIM * 5);
  player.show();
  player.move();

  //contorno labirinto

  let r = 25;
  let c = 25;

  for(let i = 0; i < c; i++) {  //mette i muri a tutta la prima riga e l'ultima
    if(i >= 4){
      labirinto[0][i].muro = true;
    }
    labirinto[r-1][i].muro = true;
    labirinto[0][i].show();
    labirinto[r-1][i].show();
  }
  for(let i = 0; i < r; i++) {   //mette i muri a tutta la prima colonna e l'ultima
    labirinto[i][0].muro = true;
    if(i <= (r - 25) || i >= (r - 21)){
      labirinto[i][c-1].muro = true;
    }
    labirinto[i][0].show();
    labirinto[i][c-1].show();
  }

  //puzzle

  let dist1 = dist(player.x, player.y, labirinto[20][6].x, labirinto[20][6].y);
  let dist2 = dist(player.x, player.y, labirinto[2][10].x, labirinto[2][10].y);
  let dist3 = dist(player.x, player.y, labirinto[6][22].x, labirinto[6][22].y);
  let dist4 = dist(player.x, player.y, labirinto[14][17].x, labirinto[14][17].y);
  
  if(pezzo1 === true){
    image(img_bianca, labirinto[20][6].x, labirinto[20][6].y, DIM, DIM);
  }else{
    image(pezzo_puzzle, labirinto[20][6].x, labirinto[20][6].y, DIM, DIM);
  }

  if(pezzo2 === true){
    image(img_bianca, labirinto[2][10].x, labirinto[2][10].y, DIM, DIM);
  }else{
    image(pezzo_puzzle, labirinto[2][10].x, labirinto[2][10].y, DIM, DIM);
  }

  if(pezzo3 === true){
    image(img_bianca, labirinto[6][22].x, labirinto[6][22].y, DIM, DIM);
  }else{
    image(pezzo_puzzle, labirinto[6][22].x, labirinto[6][22].y, DIM, DIM);
  }

  if(pezzo4 === true){
    image(img_bianca, labirinto[14][17].x, labirinto[14][17].y, DIM, DIM);
  }else{
    image(pezzo_puzzle, labirinto[14][17].x, labirinto[14][17].y, DIM, DIM);
  }

  if(dist1 < DIM && pezzo1 === false){
    text("BRAVO HAI PRESO UN PEZZO", windowWidth - (DIM * 15), windowHeight - (windowHeight - (DIM * 7)));
    pezzo1 = true;
    pezzi += 1;
  }
  if(dist2 < DIM && pezzo2 === false){
    text("BRAVO HAI PRESO UN PEZZO", windowWidth - (DIM * 15), windowHeight - (windowHeight - (DIM * 7)));
    pezzo2 = true;
    pezzi += 1;
  }
  if(dist3 < DIM && pezzo3 === false){
    text("BRAVO HAI PRESO UN PEZZO", windowWidth - (DIM * 15), windowHeight - (windowHeight - (DIM * 7)));
    pezzo3 = true;
    pezzi += 1;
  }
  if(dist4 < DIM && pezzo4 === false){
    text("BRAVO HAI PRESO UN PEZZO", windowWidth - (DIM * 15), windowHeight - (windowHeight - (DIM * 7)));
    pezzo4 = true;
    pezzi += 1;
  }

  //uscita
  if(player.x > ((c * DIM))){
    scena = 7
  }

  //creazione labirinto
  
  //RIGA 1
  labirinto[1][8].muro = true;
  labirinto[1][8].show();
  labirinto[1][20].muro = true;
  labirinto[1][20].show();
  
  //RIGA 2
  labirinto[2][8].muro = true;
  labirinto[2][8].show();
  labirinto[2][20].muro = true;
  labirinto[2][20].show();

  //RIGA 3
  labirinto[3][8].muro = true;
  labirinto[3][8].show();
  labirinto[3][20].muro = true;
  labirinto[3][20].show();

  //RIGA 4
  labirinto[4][4].muro = true;    
  labirinto[4][4].show(); 
  labirinto[4][8].muro = true;    
  labirinto[4][8].show();
  labirinto[4][9].muro = true;    
  labirinto[4][9].show();
  labirinto[4][10].muro = true;   
  labirinto[4][10].show();
  labirinto[4][11].muro = true;   
  labirinto[4][11].show();
  labirinto[4][12].muro = true;   
  labirinto[4][12].show();
  labirinto[4][13].muro = true;   
  labirinto[4][13].show();
  labirinto[4][14].muro = true;   
  labirinto[4][14].show();
  labirinto[4][15].muro = true;   
  labirinto[4][15].show();
  labirinto[4][16].muro = true;   
  labirinto[4][16].show();
  labirinto[4][20].muro = true;   
  labirinto[4][20].show();

  //RIGA 5
  labirinto[5][4].muro = true;    
  labirinto[5][4].show(); 
  labirinto[5][20].muro = true;   
  labirinto[5][20].show();
 
  //RIGA 6
  labirinto[6][4].muro = true;    
  labirinto[6][4].show(); 
  labirinto[6][20].muro = true;   
  labirinto[6][20].show(); 

  //RIGA 7
  labirinto[7][4].muro = true;    
  labirinto[7][4].show();
  labirinto[7][20].muro = true;   
  labirinto[7][20].show();

  //RIGA 8
  labirinto[8][4].muro = true;    
  labirinto[8][4].show();
  
  labirinto[8][8].muro = true;    
  labirinto[8][8].show();
  labirinto[8][9].muro = true;   
  labirinto[8][9].show();
  labirinto[8][10].muro = true;   
  labirinto[8][10].show();
  labirinto[8][11].muro = true;   
  labirinto[8][11].show();
  labirinto[8][12].muro = true;   
  labirinto[8][12].show();
  labirinto[8][13].muro = true;   
  labirinto[8][13].show();
  labirinto[8][14].muro = true;   
  labirinto[8][14].show();
  labirinto[8][15].muro = true;   
  labirinto[8][15].show();
  labirinto[8][16].muro = true;   
  labirinto[8][16].show();
  labirinto[8][20].muro = true;   
  labirinto[8][20].show();

  //RIGA 9
  labirinto[9][4].muro = true;    
  labirinto[9][4].show();
  labirinto[9][16].muro = true;   
  labirinto[9][16].show();
  labirinto[9][20].muro = true;
  labirinto[9][20].show();

  //RIGA 10
  labirinto[10][4].muro = true;   
  labirinto[10][4].show(); 
  labirinto[10][16].muro = true;   
  labirinto[10][16].show();
  labirinto[10][20].muro = true;
  labirinto[10][20].show();
  
  //RIGA 11
  labirinto[11][4].muro = true;   
  labirinto[11][4].show();
  labirinto[11][16].muro = true;   
  labirinto[11][16].show();
  labirinto[11][20].muro = true;
  labirinto[11][20].show();

  //RIGA 12
  labirinto[12][4].muro = true;   
  labirinto[12][4].show();
  labirinto[12][5].muro = true;   
  labirinto[12][5].show();
  labirinto[12][6].muro = true;   
  labirinto[12][6].show();
  labirinto[12][7].muro = true;   
  labirinto[12][7].show();
  labirinto[12][8].muro = true;   
  labirinto[12][8].show();
  labirinto[12][12].muro = true;   
  labirinto[12][12].show();
  labirinto[12][16].muro = true;   
  labirinto[12][16].show();
  labirinto[12][20].muro = true;  
  labirinto[12][20].show();

  //RIGA 13
  labirinto[13][8].muro = true;   
  labirinto[13][8].show();
  labirinto[13][12].muro = true;   
  labirinto[13][12].show();
  labirinto[13][20].muro = true;
  labirinto[13][20].show();

  //RIGA 14
  labirinto[14][8].muro = true;   
  labirinto[14][8].show();
  labirinto[14][12].muro = true;   
  labirinto[14][12].show();
  labirinto[14][20].muro = true;
  labirinto[14][20].show();

  //RIGA 15
  labirinto[15][8].muro = true;   
  labirinto[15][8].show();
  labirinto[15][12].muro = true;  
  labirinto[15][12].show();
  labirinto[15][20].muro = true;
  labirinto[15][20].show();

  //RIGA 16
  labirinto[16][4].muro = true;   
  labirinto[16][4].show();
  labirinto[16][8].muro = true;   
  labirinto[16][8].show();
  labirinto[16][9].muro = true;   
  labirinto[16][9].show();
  labirinto[16][10].muro = true;   
  labirinto[16][10].show();
  labirinto[16][11].muro = true;   
  labirinto[16][11].show();
  labirinto[16][12].muro = true;  
  labirinto[16][12].show();
  labirinto[16][16].muro = true;  
  labirinto[16][16].show();
  labirinto[16][17].muro = true;  
  labirinto[16][17].show();
  labirinto[16][18].muro = true;  
  labirinto[16][18].show();
  labirinto[16][19].muro = true;  
  labirinto[16][19].show();
  labirinto[16][20].muro = true;  
  labirinto[16][20].show();

  //RIGA 17
  labirinto[17][4].muro = true;   
  labirinto[17][4].show();
  labirinto[17][8].muro = true;   
  labirinto[17][8].show();
  labirinto[17][16].muro = true;   
  labirinto[17][16].show();
  
  //RIGA 18
  labirinto[18][4].muro = true;   
  labirinto[18][4].show();
  labirinto[18][8].muro = true;   
  labirinto[18][8].show();
  labirinto[18][16].muro = true;   
  labirinto[18][16].show();

  //RIGA 19
  labirinto[19][4].muro = true;   
  labirinto[19][4].show();
  labirinto[19][8].muro = true;   
  labirinto[19][8].show();
  labirinto[19][16].muro = true;   
  labirinto[19][16].show();

  //RIGA 20
  labirinto[20][4].muro = true;   
  labirinto[20][4].show();
  labirinto[20][8].muro = true;   
  labirinto[20][8].show();
  labirinto[20][12].muro = true;  
  labirinto[20][12].show();
  labirinto[20][16].muro = true;  
  labirinto[20][17].show();
  labirinto[20][17].muro = true;  
  labirinto[20][16].show();
  labirinto[20][18].muro = true;  
  labirinto[20][18].show();
  labirinto[20][19].muro = true;  
  labirinto[20][19].show();
  labirinto[20][20].muro = true;  
  labirinto[20][20].show();

  //RIGA 21
  labirinto[21][4].muro = true;    
  labirinto[21][4].show();
  labirinto[21][12].muro = true;  
  labirinto[21][12].show();
  
  //RIGA 22
  labirinto[22][4].muro = true;    
  labirinto[22][4].show();
  labirinto[22][12].muro = true;  
  labirinto[22][12].show();

  //RIGA 23
  labirinto[23][4].muro = true;    
  labirinto[23][4].show();
  labirinto[23][12].muro = true;  
  labirinto[23][12].show();
}

//////////////////////////////////////////////////////////////////////////////////////////////////// LABIRINTO 3 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function screen6(){                          
  background(sfondo_labirinto);
  textSize(DIM * 1.75);
  textStyle(ITALIC);
  text("tempo: " + player.tempo, windowWidth - (DIM * 14), windowHeight - (windowHeight - (DIM * 5)));
  text("tocchi: " + tocchi/2, windowWidth - (DIM * 14), windowHeight - (windowHeight - (DIM * 13)));
  text("pezzi raccolti: " + pezzi, windowWidth - (DIM * 14), windowHeight - (windowHeight - (DIM * 21)));
  image(impostazioni, windowWidth - (DIM * 6), windowHeight - (windowHeight - 10), DIM * 5, DIM * 5);
  image(casa, windowWidth - (DIM * 6), windowHeight - (windowHeight - DIM * 5), DIM * 5, DIM * 5);

  player.show();
  player.move();

  //contorno labirinto

  let r = 25;
  let c = 25;
  
  for(let i = 0; i < c; i++) {  //mette i muri a tutta la prima riga e l'ultima
    if(i >= 4){
      labirinto[0][i].muro = true;
    }
    labirinto[r-1][i].muro = true;
    labirinto[0][i].show();
    labirinto[r-1][i].show();
  }
  for(let i = 0; i < r; i++) {   //mette i muri a tutta la prima colonna e l'ultima
    labirinto[i][0].muro = true;
    if(i <= (r - 6) || i >= (r - 2)){
      labirinto[i][c-1].muro = true;
    }
    labirinto[i][0].show();
    labirinto[i][c-1].show();
  }


  //puzzle
  
  image(pezzo_puzzle, labirinto[22][12].x, labirinto[22][12].y, DIM, DIM);
  
  

  let dist1 = dist(player.x, player.y, labirinto[6][2].x, labirinto[6][2].y);
  let dist2 = dist(player.x, player.y, labirinto[22][12].x, labirinto[22][12].y);
  let dist3 = dist(player.x, player.y, labirinto[10][13].x, labirinto[10][13].y);
  let dist4 = dist(player.x, player.y, labirinto[3][21].x, labirinto[3][21].y);

  if(pezzo1 === true){
    image(img_bianca, labirinto[6][2].x, labirinto[6][2].y, DIM, DIM);
  }else{
    image(pezzo_puzzle, labirinto[6][2].x, labirinto[6][2].y, DIM, DIM);
  }

  if(pezzo2 === true){
    image(img_bianca, labirinto[22][12].x, labirinto[22][12].y, DIM, DIM);
  }else{
    image(pezzo_puzzle, labirinto[22][12].x, labirinto[22][12].y, DIM, DIM);
  }

  if(pezzo3 === true){
    image(img_bianca, labirinto[10][13].x, labirinto[10][13].y, DIM, DIM);
  }else{
    image(pezzo_puzzle, labirinto[10][13].x, labirinto[10][13].y, DIM, DIM);
  }

  if(pezzo4 === true){
    image(img_bianca, labirinto[3][21].x, labirinto[3][21].y, DIM, DIM);
  }else{
    image(pezzo_puzzle, labirinto[3][21].x, labirinto[3][21].y, DIM, DIM);
  }

  if(dist1 < DIM && pezzo1 === false){
    pezzo1 = true;
    pezzi += 1;
  }
  if(dist2 < DIM && pezzo2 === false){
    pezzo2 = true;
    pezzi += 1;
  }
  if(dist3 < DIM && pezzo3 === false){
    pezzo3 = true;
    pezzi += 1;
  }
  if(dist4 < DIM && pezzo4 === false){
    pezzo4 = true;
    pezzi += 1;
  }

  //uscita
  if(player.x > ((c * DIM))){
    scena = 8
  }

  //creazione labirinto
  
  
  labirinto[1][18].muro=true;
  labirinto[1][18].show();
  
  labirinto[2][18].muro=true;
  labirinto[2][18].show();

  labirinto[3][18].muro=true;
  labirinto[3][18].show();

  labirinto[4][1].muro=true;
  labirinto[4][1].show();
  labirinto[4][2].muro=true;
  labirinto[4][2].show();
  labirinto[4][3].muro=true;
  labirinto[4][3].show();
  labirinto[4][4].muro=true;
  labirinto[4][4].show();
  labirinto[4][8].muro=true;
  labirinto[4][8].show();
  labirinto[4][9].muro=true;
  labirinto[4][9].show();
  labirinto[4][10].muro=true;
  labirinto[4][10].show();
  labirinto[4][11].muro=true;
  labirinto[4][11].show();
  labirinto[4][12].muro=true;
  labirinto[4][12].show();
  labirinto[4][13].muro=true;
  labirinto[4][13].show();
  labirinto[4][14].muro=true;
  labirinto[4][14].show();
  labirinto[4][18].muro=true;
  labirinto[4][18].show();

  labirinto[5][4].muro=true;
  labirinto[5][4].show();
  labirinto[5][18].muro=true;
  labirinto[5][18].show();

  labirinto[6][4].muro=true;
  labirinto[6][4].show();
  labirinto[6][18].muro=true;
  labirinto[6][18].show();

  labirinto[7][4].muro=true;
  labirinto[7][4].show();
  labirinto[7][18].muro=true;
  labirinto[7][18].show();

  labirinto[8][4].muro=true;
  labirinto[8][4].show();
  labirinto[8][8].muro=true;
  labirinto[8][8].show();
  labirinto[8][9].muro=true;
  labirinto[8][9].show();
  labirinto[8][10].muro=true;
  labirinto[8][10].show();
  labirinto[8][11].muro=true;
  labirinto[8][11].show();
  labirinto[8][12].muro=true;
  labirinto[8][12].show();
  labirinto[8][13].muro=true;
  labirinto[8][13].show();
  labirinto[8][14].muro=true;
  labirinto[8][14].show();
  labirinto[8][15].muro=true;
  labirinto[8][15].show();
  labirinto[8][16].muro=true;
  labirinto[8][16].show();
  labirinto[8][17].muro=true;
  labirinto[8][17].show();
  labirinto[8][18].muro=true;
  labirinto[8][18].show();
  labirinto[8][19].muro=true;
  labirinto[8][19].show();
  labirinto[8][20].muro=true;
  labirinto[8][20].show();

  labirinto[9][4].muro=true;
  labirinto[9][4].show();
  labirinto[9][8].muro=true;
  labirinto[9][8].show();
  labirinto[9][17].muro=true;
  labirinto[9][17].show();

  labirinto[10][4].muro=true;
  labirinto[10][4].show();
  labirinto[10][8].muro=true;
  labirinto[10][8].show();
  labirinto[10][17].muro=true;
  labirinto[10][17].show();

  labirinto[11][4].muro=true;
  labirinto[11][4].show();

  labirinto[12][4].muro=true;
  labirinto[12][4].show();

  labirinto[13][4].muro=true;
  labirinto[13][4].show();
  labirinto[13][13].muro=true;
  labirinto[13][13].show();

  labirinto[14][4].muro=true;
  labirinto[14][4].show();
  labirinto[14][13].muro=true;
  labirinto[14][13].show();

  labirinto[15][4].muro=true;
  labirinto[15][4].show();
  labirinto[15][8].muro=true;
  labirinto[15][8].show();
  labirinto[15][9].muro=true;
  labirinto[15][9].show();
  labirinto[15][10].muro=true;
  labirinto[15][10].show();
  labirinto[15][11].muro=true;
  labirinto[15][11].show();
  labirinto[15][12].muro=true;
  labirinto[15][12].show();
  labirinto[15][13].muro=true;
  labirinto[15][13].show();
  labirinto[15][14].muro=true;
  labirinto[15][14].show();
  labirinto[15][15].muro=true;
  labirinto[15][15].show();
  labirinto[15][16].muro=true;
  labirinto[15][16].show();
  labirinto[15][17].muro=true;
  labirinto[15][17].show();
  labirinto[15][18].muro=true;
  labirinto[15][18].show();
  labirinto[15][19].muro=true;
  labirinto[15][19].show();
  labirinto[15][20].muro=true;
  labirinto[15][20].show();

  labirinto[16][4].muro=true;
  labirinto[16][4].show();
  labirinto[16][17].muro=true;
  labirinto[16][17].show();

  labirinto[17][4].muro=true;
  labirinto[17][4].show();
  labirinto[17][17].muro=true;
  labirinto[17][17].show();

  labirinto[18][4].muro=true;
  labirinto[18][4].show();
  labirinto[18][17].muro=true;
  labirinto[18][17].show();

  labirinto[19][10].muro=true;
  labirinto[19][10].show();
  labirinto[19][11].muro=true;
  labirinto[19][11].show();
  labirinto[19][12].muro=true;
  labirinto[19][12].show();
  labirinto[19][13].muro=true;
  labirinto[19][13].show();
  labirinto[19][17].muro=true;
  labirinto[19][17].show();
  labirinto[19][21].muro=true;
  labirinto[19][21].show();
  labirinto[19][22].muro=true;
  labirinto[19][22].show();
  labirinto[19][23].muro=true;
  labirinto[19][23].show();

  labirinto[20][10].muro=true;
  labirinto[20][10].show();
  labirinto[20][17].muro=true;
  labirinto[20][17].show();

  labirinto[21][10].muro=true;
  labirinto[21][10].show();
  labirinto[21][17].muro=true;
  labirinto[21][17].show();

  labirinto[22][10].muro=true;
  labirinto[22][10].show();
  labirinto[22][17].muro=true;
  labirinto[22][17].show();

  labirinto[23][10].muro=true;
  labirinto[23][10].show();
  labirinto[23][17].muro=true;
  labirinto[23][17].show();

}

//PUZZLE LIVELLO 1
function screen7(){                          
  background(220);
  image(casa, windowWidth - (windowWidth - 10), windowHeight - (windowHeight - DIM * 5), DIM * 5, DIM * 5);
  image(impostazioni, windowWidth - (windowWidth - 10), windowHeight - (windowHeight - 10), DIM * 5, DIM * 5);
  image(icona_galleria, windowWidth - (windowWidth - 10), windowHeight - (windowHeight - DIM * 11), DIM * 5, DIM * 5);

  if(this.image1_premuta === true || this.image2_premuta === true || this.image3_premuta === true || this.image4_premuta === true){
    mouseDragged();
  }else{
    mouseReleased();
  }

  image(gioconda_alto_destra, img1X, img1Y, DIM * 5, DIM * 5);
  image(gioconda_alto_sinistra, img2X, img2Y, DIM * 5, DIM * 5);
  image(gioconda_basso_destra, img3X, img3Y, DIM * 5, DIM * 5);
  image(gioconda_basso_sinistra, img4X, img4Y, DIM * 5, DIM * 5);

  if((dist(img1X, img1Y, img2X, img2Y)) < (DIM * 6) && (dist(img2X, img2Y, img4X, img4Y)) < (DIM * 6) && (dist(img4X, img4Y, img3X, img3Y)) < (DIM * 6) && (dist(img3X, img3Y, img1X, img1Y)) < (DIM * 6)){
    textStyle(BOLDITALIC);
    text("BRAVO HAI COMPLETATO L'IMMAGINE", DIM * 10, DIM * 20);
    text("VAI A GUARDARE NELLA GALLERIA", DIM * 10, DIM * 22);
  }
}
  

//PUZZLE LIVELLO 2
function screen8(){                          
  background(220);
  image(casa, windowWidth - (windowWidth - 10), windowHeight - (windowHeight - DIM * 5), DIM * 5, DIM * 5);
  image(impostazioni, windowWidth - (windowWidth - 10), windowHeight - (windowHeight - 10), DIM * 5, DIM * 5);
  image(icona_galleria, windowWidth - (windowWidth - 10), windowHeight - (windowHeight - DIM * 11), DIM * 5, DIM * 5);
  
  if(this.image1_premuta === true || this.image2_premuta === true || this.image3_premuta === true || this.image4_premuta === true){
    mouseDragged();
  }else{
    mouseReleased();
  }

  image(vaso_alto_destra, img1X, img1Y, DIM * 5, DIM * 5);
  image(vaso_alto_sinistra, img2X, img2Y, DIM * 5, DIM * 5);
  image(vaso_basso_destra, img3X, img3Y, DIM * 5, DIM * 5);
  image(vaso_basso_sinistra, img4X, img4Y, DIM * 5, DIM * 5);

  if((dist(img1X, img1Y, img2X, img2Y)) < (DIM * 6) && (dist(img2X, img2Y, img4X, img4Y)) < (DIM * 6) && (dist(img4X, img4Y, img3X, img3Y)) < (DIM * 6) && (dist(img3X, img3Y, img1X, img1Y)) < (DIM * 6)){
    textStyle(BOLDITALIC);
    text("BRAVO HAI COMPLETATO L'IMMAGINE", DIM * 10, DIM * 20);
    text("VAI A GUARDARE NELLA GALLERIA", DIM * 10, DIM * 22);
  }
}

//PUZZLE LIVELLO 3
function screen9(){                          
  background(220);
  image(casa, windowWidth - (windowWidth - 10), windowHeight - (windowHeight - DIM * 5), DIM * 5, DIM * 5);
  image(icona_galleria, windowWidth - (windowWidth - 10), windowHeight - (windowHeight - DIM * 11), DIM * 5, DIM * 5);
  image(impostazioni, windowWidth - (windowWidth - 10), windowHeight - (windowHeight - 10), DIM * 5, DIM * 5);

  if(this.image1_premuta === true || this.image2_premuta === true || this.image3_premuta === true || this.image4_premuta === true){
    mouseDragged();
  }else{
    mouseReleased();
  }

  image(onde_alto_destra, img1X, img1Y, DIM * 5, DIM * 5);
  image(onde_alto_sinistra, img2X, img2Y, DIM * 5, DIM * 5);
  image(onde_basso_destra, img3X, img3Y, DIM * 5, DIM * 5);
  image(onde_basso_sinistra, img4X, img4Y, DIM * 5, DIM * 5);

  if((dist(img1X, img1Y, img2X, img2Y)) < (DIM * 6) && (dist(img2X, img2Y, img4X, img4Y)) < (DIM * 6) && (dist(img4X, img4Y, img3X, img3Y)) < (DIM * 6) && (dist(img3X, img3Y, img1X, img1Y)) < (DIM * 6)){
    textStyle(BOLDITALIC);
    text("BRAVO HAI COMPLETATO L'IMMAGINE", DIM * 10, DIM * 20);
    text("VAI A GUARDARE NELLA GALLERIA", DIM * 10, DIM * 22);
  }
}

//GALLERIA
function screen10(){
  background(sfondo_galleria);
  image(casa, windowWidth - (windowWidth - 10), windowHeight - (windowHeight - DIM * 5), DIM * 5, DIM * 5);
  image(impostazioni, windowWidth - (windowWidth - 10), windowHeight - (windowHeight - 10), DIM * 5, DIM * 5);
  image(gioconda, windowWidth - (windowWidth - (DIM * 10)), windowHeight - (windowHeight - (DIM * 5)));
  image(vaso, windowWidth - (windowWidth - (DIM * 20)), windowHeight - (windowHeight - DIM * 5));
  image(onde, windowWidth - (windowWidth - (DIM * 30)), windowHeight - (windowHeight - DIM * 5));
}
