class Player{

  //COSTRUTTORE
  constructor(){
    this.dim = 60;
    this.x = labirinto[1][2].x;
    this.y = labirinto[1][2].y;
    this.x_inizio = labirinto[1][2].x;
    this.y_inizio = labirinto[1][2].y;
    this.tempo = 0;
  }

  //funzione che permette di mostrare a video l'immagine dell'omino
  show(){
    ellipse(this.x + DIM/1.35, this.y + DIM/1.33, DIM * 1.5, DIM * 1.5);
    image(player_image, this.x, this.y, DIM * 1.5, DIM * 1.5);
  }

  //funzione che detta i movimenti dello sprite
  move(){
    if(mousePressed){
      this.tempo = round(millis() / 1000);
      mouseDragged();
    }else{
      mouseReleased();
    }
  }
}