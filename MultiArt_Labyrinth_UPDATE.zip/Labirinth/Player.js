class Player{

  //COSTRUTTORE
  constructor(x, y){
    //coordinate della prima macchina
    this.dim = 60;
    this.x = x; //122;
    this.y = y; //68;
  }

  //funzione che permette di mostrare a video l'immagine dell'omino
  show(){
    image(player_image, this.x, this.y);
  }

  //funzione che detta i movimenti dello sprite
  move(){
    if(mousePressed){
      mouseDragged();
    }else{
      mouseReleased();
    }
  }

  collision(){
    let r = floor(this.y / DIM); 
    let c = floor(this.x / DIM);
  
    if( labirinto[r][c].muro && (this.x + 60) >= labirinto[r][c].muro.x && (this.x + 60) < (labirinto[r][c].muro.x + 3) ){  //sinistra
      mouseReleased();
      this.x = this.x - 10;
      console.log("collisione sinistra");  //
      console.log(labirinto[r][c]);
      console.log(this.x, this.y);
    }
  
    if( labirinto[r][c].muro && this.x <= (labirinto[r][c].muro.x + DIM) && this.x > (labirinto[r][c].muro.x + DIM - 3) ){  //destra
      mouseReleased();
      this.x = this.x + 10; 
      console.log("collisione destra");  //CHECK
      console.log(labirinto[r][c]);
      console.log(this.x, this.y);
    }
  
    /*if(labirinto[r][c].muro && player.y >= (labirinto[r][c].y - DIM) && (player.y - player.dim) > (labirinto[r][c].y - DIM + 3)){  //solo bordo sotto 
      mouseReleased();
      //player.y = player.y + 10;
      console.log("collisione sotto");
      console.log(labirinto[r][c]);
      console.log(player.x, player.y);
    }
  
    if(labirinto[r][c].muro && player.y >= (labirinto[r][c].y - DIM) && (player.y - player.dim) > (labirinto[r][c].y - DIM + 3)){  //solo bordo alto
      mouseReleased();
      player.y = player.y + 10;
      console.log("collisione sopra");  //CHECK
      console.log(labirinto[r][c]);
      console.log(player.x, player.y);
    }*/
    console.log(player.x, labirinto[r][c].x);
    console.log("Y: ", this.y);
    
  }
}